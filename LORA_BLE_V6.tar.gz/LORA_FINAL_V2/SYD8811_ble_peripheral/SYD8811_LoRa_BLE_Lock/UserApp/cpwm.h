/**
 * Copyright (c) 2020, Freqchip
 * 
 * All rights reserved.
 * 
 * 
 */

#ifndef CPWM_H
#define CPWM_H
 
void SPCStart(void);
void SPCStop(void); 

 
#endif

