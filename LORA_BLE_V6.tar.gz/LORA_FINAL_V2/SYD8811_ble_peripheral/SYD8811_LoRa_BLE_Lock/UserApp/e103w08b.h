/*
 * E103W08B.h
 *
 *  Created on: 2021-7-30
 *      Author: Yangba
 */
 
#ifndef E103W08B_H_
#define E103W08B_H_

#include "stdint.h"
#include "stdbool.h"
#include "armcm0.h"

#define E103W08B_EN  	GPIO_11
// #define E103W08B_RST  GPIO_8

#define MAX_SIZE_LENGTH 	  1024

//#define MAX_RX_SIZE_LENGTH  200

typedef struct
{
	uint8_t data[MAX_SIZE_LENGTH],reciveflag,start_rx;
	uint32_t header,tail,revcnt;
	uint16_t idlecount;
} e103w08b_rx_buff_def;

typedef struct
{
	uint8_t data[MAX_SIZE_LENGTH];
	uint32_t length;
	
} e103w08b_tx_buff_def;

extern e103w08b_tx_buff_def e103w08_utx_buf;

extern e103w08b_rx_buff_def e103w08_urx_buf;

extern void e103w08b_init(void);
extern void e103w08b_uart_write(uint8_t data);
extern void e103w08b_uart_write_buff(uint8_t *pData,uint8_t len);

#endif /* E103W08B_H_ */

