/******************** (C) COPYRIGHT 2020  *****************************
* File Name          : motor.c
* Author             : 
* Version            : V1.00
* Date               : 2020.12.13
* Description        : Motor module processe
*******************************************************************************
History:
	2020-12	First version.
*******************************************************************************/


/* Includes ------------------------------------------------------------------*/
#include "gpio.h"
#include "motor.h"
#include "config.h"
#include "user.h"

#define 	MOTOREN		//ʹ�ܿ���

uint8_t MotorState = MOTOR_STOP;

/*MOTOREN����ʹ�ܣ�DEBUG���������ӡʹ�ܡ�����ʹ�ܻ�ʹ��Ƭ����λ*/

/* Private variables ---------------------------------------------------------*/
void MotorInit(void)
{
	MotorState = MOTOR_STOP;
	
	// ����Ϊ�������
//	GPIO_Set_Output(Motor_INA|Motor_INB);
	
	//��ʼ�����
	//gpio_set_pin_value(GPIO_PORT_D,GPIO_BIT_4,1);
	GPIO_Pin_Clear(U32BIT(Motor_INA));
	GPIO_Pin_Clear(U32BIT(Motor_INB));
	
}

void MotorStartForward(void)
{
	flg_do_closelockOK = 0;
	flg_do_closelockcmd = 0;

  MotorState = MOTOR_FORWARD;
#ifdef MOTOREN 
	GPIO_Pin_Clear(U32BIT(Motor_INA));
	GPIO_Pin_Set(U32BIT(Motor_INB));
#endif 
	
}

void MotorStartReverse(void)
{
	flg_do_closelockcmd = 1;
	_user.closelock_2s = 1000/2;	//��1��
  MotorState = MOTOR_REVERSE;
#ifdef MOTOREN 
	GPIO_Pin_Clear(U32BIT(Motor_INB));
	GPIO_Pin_Set(U32BIT(Motor_INA));
#endif
  
}

void MotorStop(void)
{
	MotorState = MOTOR_STOP;
#ifdef MOTOREN 
	GPIO_Pin_Clear(U32BIT(Motor_INA));
	GPIO_Pin_Clear(U32BIT(Motor_INB));
#endif

}

void MotorEventHandle(void)
{

}


/********************** (C) COPYRIGHT 2020-12-13 ***********************/

