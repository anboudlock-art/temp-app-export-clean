                AREA    STACK, NOINIT, READWRITE, ALIGN=3
Stack_Size      EQU     0x00001000

Stack_Mem       SPACE   Stack_Size
__initial_sp

                EXPORT  __initial_sp

                AREA    HEAP, NOINIT, READWRITE, ALIGN=3
__heap_base
Heap_Mem        SPACE   0x00000400
__heap_limit

                EXPORT  __heap_base
                EXPORT  __heap_limit

                PRESERVE8
                END
