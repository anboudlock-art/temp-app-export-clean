/* uart.c - UART driver implementation */
#include "uart.h"
#include "delay.h"

/* UART initialization */
void uart_init(UART_Type *uart, uint32_t baud_rate) {
    /* Basic UART initialization */
    /* In real implementation, configure registers */
}

void uart_send_byte(UART_Type *uart, uint8_t data) {
    /* Wait for TX ready */
    while(!(uart->STATUS & UART_STATUS_TX_EMPTY));
    uart->DATA = data;
}

uint8_t uart_receive_byte(UART_Type *uart) {
    /* Wait for RX data */
    while(!(uart->STATUS & UART_STATUS_RX_FULL));
    return uart->DATA;
}

bool uart_tx_ready(UART_Type *uart) {
    return (uart->STATUS & UART_STATUS_TX_EMPTY) != 0;
}

bool uart_rx_available(UART_Type *uart) {
    return (uart->STATUS & UART_STATUS_RX_FULL) != 0;
}

void uart_send_string(UART_Type *uart, const char *str) {
    while(*str) {
        uart_send_byte(uart, *str++);
    }
}

void uart_send_buffer(UART_Type *uart, const uint8_t *buf, uint32_t len) {
    while(len--) {
        uart_send_byte(uart, *buf++);
    }
}
