/* rtc.h - Real Time Clock Driver */
#ifndef RTC_H
#define RTC_H

#include <stdint.h>
#include <stdbool.h>

/* RTC time structure */
typedef struct {
    uint8_t second;
    uint8_t minute;
    uint8_t hour;
    uint8_t day;
    uint8_t month;
    uint16_t year;
} rtc_time_t;

/* RTC alarm structure */
typedef struct {
    uint8_t minute;
    uint8_t hour;
    uint8_t day;
    uint8_t month;
    uint16_t year;
    bool enabled;
} rtc_alarm_t;

/* RTC functions */
void rtc_init(void);
void rtc_set_time(const rtc_time_t *time);
void rtc_get_time(rtc_time_t *time);
uint32_t rtc_get_timestamp(void);
void rtc_set_alarm(const rtc_alarm_t *alarm);
void rtc_clear_alarm(void);
bool rtc_alarm_triggered(void);
void rtc_clear_alarm_flag(void);

/* Utility functions */
uint32_t rtc_time_to_timestamp(const rtc_time_t *time);
void rtc_timestamp_to_time(uint32_t timestamp, rtc_time_t *time);

#endif /* RTC_H */
