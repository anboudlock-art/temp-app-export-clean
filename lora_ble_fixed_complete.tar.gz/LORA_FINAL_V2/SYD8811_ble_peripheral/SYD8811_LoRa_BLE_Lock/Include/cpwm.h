/* cpwm.h - Complementary PWM Driver */
#ifndef CPWM_H
#define CPWM_H

#include <stdint.h>
#include <stdbool.h>

/* PWM channels */
typedef enum {
    PWM_CHANNEL_0 = 0,
    PWM_CHANNEL_1,
    PWM_CHANNEL_2,
    PWM_CHANNEL_3
} pwm_channel_t;

/* PWM configuration */
typedef struct {
    uint32_t frequency_hz;
    uint8_t duty_cycle;  /* 0-100% */
    bool complementary;
    bool dead_time_enable;
    uint32_t dead_time_ns;
} pwm_config_t;

/* PWM functions */
void cpwm_init(void);
void cpwm_start(pwm_channel_t channel, const pwm_config_t *config);
void cpwm_stop(pwm_channel_t channel);
void cpwm_set_duty(pwm_channel_t channel, uint8_t duty_cycle);
void cpwm_set_frequency(pwm_channel_t channel, uint32_t frequency_hz);
bool cpwm_is_running(pwm_channel_t channel);

#endif /* CPWM_H */
