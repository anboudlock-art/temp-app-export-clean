/* user.h - User Configuration and Data */
#ifndef USER_H
#define USER_H

#include <stdint.h>
#include <stdbool.h>

/* User lock structure */
typedef struct {
    uint8_t lock_sn8array[8];
    uint8_t lock_state;
    uint8_t battery_level;
    uint32_t unlock_count;
    uint32_t last_unlock_time;
    uint8_t ble_mac[6];
    uint8_t lora_address[2];
} user_lock_t;

/* User functions */
void user_init(void);
user_lock_t *user_get_lock_data(void);
bool user_save_lock_data(void);
bool user_load_lock_data(void);
void user_set_lock_state(uint8_t state);
uint8_t user_get_lock_state(void);
void user_increment_unlock_count(void);

#endif /* USER_H */
