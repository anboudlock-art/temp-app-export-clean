/* os_timer.h - OS Timer Abstraction */
#ifndef OS_TIMER_H
#define OS_TIMER_H

#include <stdint.h>
#include <stdbool.h>

/* Timer callback type */
typedef void (*timer_callback_t)(void *arg);

/* Timer handle */
typedef struct {
    uint32_t id;
    uint32_t interval_ms;
    uint32_t expiry_time;
    timer_callback_t callback;
    void *arg;
    bool periodic;
    bool active;
} os_timer_t;

/* OS timer functions */
void os_timer_init(void);
os_timer_t *os_timer_create(uint32_t interval_ms, timer_callback_t callback, void *arg, bool periodic);
bool os_timer_start(os_timer_t *timer);
bool os_timer_stop(os_timer_t *timer);
bool os_timer_delete(os_timer_t *timer);
void os_timer_tick(void);
uint32_t os_timer_get_tick_count(void);
void os_timer_delay(uint32_t ms);

#endif /* OS_TIMER_H */
