/* softtimer.h - Software Timer */
#ifndef SOFTTIMER_H
#define SOFTTIMER_H

#include <stdint.h>
#include <stdbool.h>

/* Timer callback */
typedef void (*softtimer_callback_t)(void);

/* Timer structure */
typedef struct {
    uint32_t interval;
    uint32_t last_tick;
    softtimer_callback_t callback;
    bool active;
    bool repeat;
} softtimer_t;

/* Functions */
void softtimer_init(void);
void softtimer_tick(void);
bool softtimer_create(softtimer_t *timer, uint32_t interval_ms, softtimer_callback_t callback, bool repeat);
bool softtimer_start(softtimer_t *timer);
bool softtimer_stop(softtimer_t *timer);
bool softtimer_reset(softtimer_t *timer);
uint32_t softtimer_get_tick(void);

#endif /* SOFTTIMER_H */
