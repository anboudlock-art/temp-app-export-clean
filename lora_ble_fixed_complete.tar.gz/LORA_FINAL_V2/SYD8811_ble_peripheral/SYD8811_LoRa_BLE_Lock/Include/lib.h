/* lib.h - SYD8811 Standard Library */
#ifndef LIB_H
#define LIB_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

/* Basic types */
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef int8_t   s8;
typedef int16_t  s16;
typedef int32_t  s32;

/* Boolean */
typedef bool     BOOL;
#define TRUE     true
#define FALSE    false

/* Memory operations */
void *memcpy(void *dest, const void *src, size_t n);
void *memset(void *s, int c, size_t n);
int memcmp(const void *s1, const void *s2, size_t n);

/* String operations */
size_t strlen(const char *s);
char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t n);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);

/* Math functions */
int abs(int x);
long labs(long x);

/* Utility macros */
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define ABS(x)   ((x)<0?-(x):(x))
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))

#endif /* LIB_H */
