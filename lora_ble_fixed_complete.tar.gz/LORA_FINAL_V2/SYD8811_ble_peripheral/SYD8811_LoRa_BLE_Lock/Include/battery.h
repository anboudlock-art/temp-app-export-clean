/* battery.h - Battery Management */
#ifndef BATTERY_H
#define BATTERY_H

#include <stdint.h>
#include <stdbool.h>

/* Battery status */
typedef enum {
    BATTERY_STATUS_CHARGING = 0,
    BATTERY_STATUS_DISCHARGING,
    BATTERY_STATUS_FULL,
    BATTERY_STATUS_EMPTY,
    BATTERY_STATUS_FAULT
} battery_status_t;

/* Battery information */
typedef struct {
    uint16_t voltage_mv;      // Voltage in millivolts
    uint8_t percentage;       // Charge percentage (0-100)
    battery_status_t status;  // Current status
    uint16_t current_ma;      // Current in milliamps
    uint16_t capacity_mah;    // Capacity in mAh
} battery_info_t;

/* Battery functions */
void battery_init(void);
bool battery_get_info(battery_info_t *info);
uint16_t battery_get_voltage(void);
uint8_t battery_get_percentage(void);
battery_status_t battery_get_status(void);
bool battery_is_low(void);
bool battery_is_critical(void);
void battery_update(void);

#endif /* BATTERY_H */
