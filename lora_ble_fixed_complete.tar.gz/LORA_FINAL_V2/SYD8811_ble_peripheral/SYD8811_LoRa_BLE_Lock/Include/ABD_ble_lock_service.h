/* ABD_ble_lock_service.h - BLE Lock Service Definitions */
#ifndef ABD_BLE_LOCK_SERVICE_H
#define ABD_BLE_LOCK_SERVICE_H

#include <stdint.h>
#include <stdbool.h>

/* BLE service UUIDs */
#define BLE_LOCK_SERVICE_UUID    0x1800
#define BLE_LOCK_CHAR_UUID       0x2A00

/* BLE characteristic properties */
#define BLE_PROP_READ            (1 << 0)
#define BLE_PROP_WRITE           (1 << 1)
#define BLE_PROP_NOTIFY          (1 << 2)
#define BLE_PROP_INDICATE        (1 << 3)

/* BLE event types */
typedef enum {
    BLE_EVT_CONNECTED = 0,
    BLE_EVT_DISCONNECTED,
    BLE_EVT_DATA_RECEIVED,
    BLE_EVT_DATA_SENT,
    BLE_EVT_ADV_STARTED,
    BLE_EVT_ADV_STOPPED
} ble_evt_type_t;

/* BLE event structure */
typedef struct {
    ble_evt_type_t type;
    uint8_t *data;
    uint16_t length;
    uint16_t handle;
} ble_evt_t;

/* BLE callback type */
typedef void (*ble_callback_t)(ble_evt_t *evt);

/* BLE functions */
void ble_service_init(ble_callback_t callback);
bool ble_service_send_data(uint8_t *data, uint16_t length);
bool ble_service_start_advertise(void);
bool ble_service_stop_advertise(void);
bool ble_service_is_connected(void);
uint8_t *ble_service_get_address(void);

#endif /* ABD_BLE_LOCK_SERVICE_H */
