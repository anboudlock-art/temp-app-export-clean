/* input.h - Input Device Driver */
#ifndef INPUT_H
#define INPUT_H

#include <stdint.h>
#include <stdbool.h>

/* Input events */
typedef enum {
    INPUT_EVENT_NONE = 0,
    INPUT_EVENT_PRESS,
    INPUT_EVENT_RELEASE,
    INPUT_EVENT_HOLD,
    INPUT_EVENT_CLICK,
    INPUT_EVENT_DOUBLE_CLICK,
    INPUT_EVENT_LONG_PRESS
} input_event_t;

/* Input callback */
typedef void (*input_callback_t)(input_event_t event, uint32_t param);

/* Input functions */
void input_init(void);
void input_set_callback(input_callback_t callback);
bool input_get_state(void);
input_event_t input_get_event(void);
void input_update(void);
void input_debounce(void);

#endif /* INPUT_H */
