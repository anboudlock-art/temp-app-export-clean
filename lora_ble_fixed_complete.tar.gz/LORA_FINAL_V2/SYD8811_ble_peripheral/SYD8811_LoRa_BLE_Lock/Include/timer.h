/* timer.h - Timer Driver for SYD8811 */
#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>
#include <stdbool.h>

/* Timer registers */
typedef struct {
    volatile uint32_t LOAD;
    volatile uint32_t VALUE;
    volatile uint32_t CONTROL;
    volatile uint32_t INT_CLR;
    volatile uint32_t RIS;
    volatile uint32_t MIS;
    volatile uint32_t BGLOAD;
} Timer_Type;

/* Timer instances */
#define TIMER0_BASE 0x40020000
#define TIMER1_BASE 0x40021000
#define TIMER0 ((Timer_Type *)TIMER0_BASE)
#define TIMER1 ((Timer_Type *)TIMER1_BASE)

/* Control register bits */
#define TIMER_ENABLE      (1 << 0)
#define TIMER_PERIODIC    (1 << 1)
#define TIMER_INT_ENABLE  (1 << 2)
#define TIMER_32BIT       (1 << 3)
#define TIMER_PRESCALE_1  (0 << 4)
#define TIMER_PRESCALE_16 (1 << 4)
#define TIMER_PRESCALE_256 (2 << 4)

/* Functions */
void timer_init(Timer_Type *timer, uint32_t interval_ms, bool periodic);
void timer_start(Timer_Type *timer);
void timer_stop(Timer_Type *timer);
void timer_clear_interrupt(Timer_Type *timer);
bool timer_interrupt_pending(Timer_Type *timer);
uint32_t timer_get_value(Timer_Type *timer);

#endif /* TIMER_H */
