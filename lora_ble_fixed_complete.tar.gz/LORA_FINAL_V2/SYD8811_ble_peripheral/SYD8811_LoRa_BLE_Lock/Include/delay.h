/* delay.h - Delay Functions */
#ifndef DELAY_H
#define DELAY_H

#include <stdint.h>

/* Delay functions */
void delay_ms(uint32_t ms);
void delay_us(uint32_t us);
void delay_cycles(uint32_t cycles);

/* Inline delay functions */
static inline void delay_ns(uint32_t ns) {
    /* Approximate delay - adjust based on CPU frequency */
    volatile uint32_t count = ns / 10;
    while(count--) {
        __asm__ volatile ("nop");
    }
}

/* Macro wrappers */
#define DELAY_MS(ms)   delay_ms(ms)
#define DELAY_US(us)   delay_us(us)
#define DELAY_NS(ns)   delay_ns(ns)

#endif /* DELAY_H */
