/* gpio.h - GPIO Driver for SYD8811 */
#ifndef GPIO_H
#define GPIO_H

#include <stdint.h>
#include <stdbool.h>

/* GPIO registers */
typedef struct {
    volatile uint32_t DATA;
    volatile uint32_t DIR;
    volatile uint32_t PULL;
    volatile uint32_t DRIVE;
    volatile uint32_t INT_EN;
    volatile uint32_t INT_TYPE;
    volatile uint32_t INT_STATUS;
    volatile uint32_t INT_CLEAR;
} GPIO_Type;

/* GPIO ports */
#define GPIOA_BASE 0x40040000
#define GPIOB_BASE 0x40041000
#define GPIOC_BASE 0x40042000
#define GPIOA ((GPIO_Type *)GPIOA_BASE)
#define GPIOB ((GPIO_Type *)GPIOB_BASE)
#define GPIOC ((GPIO_Type *)GPIOC_BASE)

/* GPIO pins */
#define GPIO_PIN_0   (1 << 0)
#define GPIO_PIN_1   (1 << 1)
#define GPIO_PIN_2   (1 << 2)
#define GPIO_PIN_3   (1 << 3)
#define GPIO_PIN_4   (1 << 4)
#define GPIO_PIN_5   (1 << 5)
#define GPIO_PIN_6   (1 << 6)
#define GPIO_PIN_7   (1 << 7)
#define GPIO_PIN_8   (1 << 8)
#define GPIO_PIN_9   (1 << 9)
#define GPIO_PIN_10  (1 << 10)
#define GPIO_PIN_11  (1 << 11)
#define GPIO_PIN_12  (1 << 12)
#define GPIO_PIN_13  (1 << 13)
#define GPIO_PIN_14  (1 << 14)
#define GPIO_PIN_15  (1 << 15)
#define GPIO_PIN_16  (1 << 16)
#define GPIO_PIN_17  (1 << 17)
#define GPIO_PIN_18  (1 << 18)
#define GPIO_PIN_19  (1 << 19)
#define GPIO_PIN_20  (1 << 20)
#define GPIO_PIN_21  (1 << 21)
#define GPIO_PIN_22  (1 << 22)

/* Direction */
#define GPIO_INPUT  0
#define GPIO_OUTPUT 1

/* Pull configuration */
#define GPIO_PULL_NONE  0
#define GPIO_PULL_UP    1
#define GPIO_PULL_DOWN  2

/* Drive strength */
#define GPIO_DRIVE_2MA  0
#define GPIO_DRIVE_4MA  1
#define GPIO_DRIVE_8MA  2
#define GPIO_DRIVE_12MA 3

/* Functions */
void gpio_set_direction(GPIO_Type *gpio, uint32_t pin, bool output);
void gpio_set_level(GPIO_Type *gpio, uint32_t pin, bool high);
bool gpio_get_level(GPIO_Type *gpio, uint32_t pin);
void gpio_set_pull(GPIO_Type *gpio, uint32_t pin, uint32_t pull);
void gpio_set_drive(GPIO_Type *gpio, uint32_t pin, uint32_t drive);
void gpio_toggle(GPIO_Type *gpio, uint32_t pin);

#endif /* GPIO_H */
