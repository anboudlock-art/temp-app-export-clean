/* ota.h - Over-The-Air Update */
#ifndef OTA_H
#define OTA_H

#include <stdint.h>
#include <stdbool.h>

/* OTA status */
typedef enum {
    OTA_STATUS_IDLE = 0,
    OTA_STATUS_RECEIVING,
    OTA_STATUS_VERIFYING,
    OTA_STATUS_WRITING,
    OTA_STATUS_COMPLETE,
    OTA_STATUS_ERROR
} ota_status_t;

/* OTA information */
typedef struct {
    uint32_t total_size;
    uint32_t received_size;
    uint32_t crc32;
    uint8_t version[4];
    ota_status_t status;
} ota_info_t;

/* OTA functions */
void ota_init(void);
bool ota_start(uint32_t total_size, const uint8_t *version);
bool ota_write_data(const uint8_t *data, uint32_t size);
bool ota_finish(void);
bool ota_verify(void);
ota_status_t ota_get_status(void);
ota_info_t *ota_get_info(void);
void ota_reset(void);

#endif /* OTA_H */
