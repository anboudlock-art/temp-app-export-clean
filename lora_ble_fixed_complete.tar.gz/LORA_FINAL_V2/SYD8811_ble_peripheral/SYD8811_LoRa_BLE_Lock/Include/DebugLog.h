/* DebugLog.h - Debug Logging System */
#ifndef DEBUGLOG_H
#define DEBUGLOG_H

#include <stdint.h>
#include <stdarg.h>

/* Log levels */
typedef enum {
    LOG_NONE = 0,
    LOG_ERROR,
    LOG_WARNING,
    LOG_INFO,
    LOG_DEBUG,
    LOG_VERBOSE
} log_level_t;

/* Debug output functions */
void dbg_printf(const char *fmt, ...);
void DBGPRINTF(const char *fmt, ...);
void DEBUG_PRINT(const char *fmt, ...);

/* Log macros */
#define LOG_ERROR(fmt, ...)   dbg_printf("[E] " fmt, ##__VA_ARGS__)
#define LOG_WARNING(fmt, ...) dbg_printf("[W] " fmt, ##__VA_ARGS__)
#define LOG_INFO(fmt, ...)    dbg_printf("[I] " fmt, ##__VA_ARGS__)
#define LOG_DEBUG(fmt, ...)   dbg_printf("[D] " fmt, ##__VA_ARGS__)

/* Default implementations (empty) */
#ifndef dbg_printf
#define dbg_printf(...)
#endif

#ifndef DBGPRINTF
#define DBGPRINTF(...)
#endif

#ifndef DEBUG_PRINT
#define DEBUG_PRINT(...)
#endif

#endif /* DEBUGLOG_H */
