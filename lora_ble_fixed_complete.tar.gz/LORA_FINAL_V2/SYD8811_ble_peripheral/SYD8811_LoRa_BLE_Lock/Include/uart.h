/* uart.h - UART Driver for SYD8811 */
#ifndef UART_H
#define UART_H

#include <stdint.h>
#include <stdbool.h>

/* UART register structure */
typedef struct {
    volatile uint32_t DATA;
    volatile uint32_t STATUS;
    volatile uint32_t CLOCK;
    volatile uint32_t CONFIG;
    volatile uint32_t INT_EN;
    volatile uint32_t INT_STATUS;
    volatile uint32_t FIFO_CTRL;
    volatile uint32_t BAUD_DIV;
} UART_Type;

/* UART instances */
#define UART0_BASE 0x40010000
#define UART1_BASE 0x40011000
#define UART0 ((UART_Type *)UART0_BASE)
#define UART1 ((UART_Type *)UART1_BASE)

/* Baud rates */
#define UART_BAUD_9600    0
#define UART_BAUD_19200   1
#define UART_BAUD_38400   2
#define UART_BAUD_57600   3
#define UART_BAUD_115200  4

/* Status bits */
#define UART_STATUS_TX_EMPTY   (1 << 0)
#define UART_STATUS_TX_FULL    (1 << 1)
#define UART_STATUS_RX_EMPTY   (1 << 2)
#define UART_STATUS_RX_FULL    (1 << 3)
#define UART_STATUS_BUSY       (1 << 4)

/* Functions */
void uart_init(UART_Type *uart, uint32_t baud_rate);
void uart_send_byte(UART_Type *uart, uint8_t data);
uint8_t uart_receive_byte(UART_Type *uart);
bool uart_tx_ready(UART_Type *uart);
bool uart_rx_available(UART_Type *uart);
void uart_send_string(UART_Type *uart, const char *str);
void uart_send_buffer(UART_Type *uart, const uint8_t *buf, uint32_t len);

#endif /* UART_H */
