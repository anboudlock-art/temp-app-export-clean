/* ARMCM0.h - Fixed version without IRQn_Type dependency */
#ifndef ARMCM0_H
#define ARMCM0_H

#include <stdint.h>

/* CMSIS standard types */
#define __IO volatile
#define __I  volatile const
#define __O  volatile

/* Memory mapping */
#define FLASH_BASE   0x00000000UL
#define RAM_BASE     0x20000000UL
#define PERIPH_BASE  0x40000000UL

/* System Control Block (SCB) */
typedef struct {
    __I  uint32_t CPUID;
    __IO uint32_t ICSR;
    __IO uint32_t VTOR;
    __IO uint32_t AIRCR;
    __IO uint32_t SCR;
    __IO uint32_t CCR;
    __IO uint32_t SHPR[3];
    __IO uint32_t SHCSR;
    __IO uint32_t CFSR;
    __IO uint32_t HFSR;
    __IO uint32_t DFSR;
    __IO uint32_t MMFAR;
    __IO uint32_t BFAR;
    __IO uint32_t AFSR;
} SCB_Type;

#define SCB_BASE  (0xE000ED00UL)
#define SCB       ((SCB_Type *)SCB_BASE)

/* Nested Vectored Interrupt Controller (NVIC) */
typedef struct {
    __IO uint32_t ISER[1];
    uint32_t RESERVED0[31];
    __IO uint32_t ICER[1];
    uint32_t RESERVED1[31];
    __IO uint32_t ISPR[1];
    uint32_t RESERVED2[31];
    __IO uint32_t ICPR[1];
    uint32_t RESERVED3[31];
    uint32_t RESERVED4[64];
    __IO uint32_t IP[8];
} NVIC_Type;

#define NVIC_BASE (0xE000E100UL)
#define NVIC      ((NVIC_Type *)NVIC_BASE)

/* System Tick Timer (SysTick) */
typedef struct {
    __IO uint32_t CTRL;
    __IO uint32_t LOAD;
    __IO uint32_t VAL;
    __I  uint32_t CALIB;
} SysTick_Type;

#define SysTick_BASE (0xE000E010UL)
#define SysTick      ((SysTick_Type *)SysTick_BASE)

/* Core functions */
static inline void __enable_irq(void) { __asm volatile ("cpsie i"); }
static inline void __disable_irq(void) { __asm volatile ("cpsid i"); }
static inline void __NOP(void) { __asm volatile ("nop"); }
static inline void __WFI(void) { __asm volatile ("wfi"); }
static inline void __WFE(void) { __asm volatile ("wfe"); }
static inline void __SEV(void) { __asm volatile ("sev"); }
static inline void __ISB(void) { __asm volatile ("isb"); }
static inline void __DSB(void) { __asm volatile ("dsb"); }
static inline void __DMB(void) { __asm volatile ("dmb"); }

/* Simple NVIC functions without IRQn_Type */
static inline void NVIC_EnableIRQ(uint32_t IRQn) {
    NVIC->ISER[0] = (1 << (IRQn & 0x1F));
}

static inline void NVIC_DisableIRQ(uint32_t IRQn) {
    NVIC->ICER[0] = (1 << (IRQn & 0x1F));
}

static inline void NVIC_SetPriority(uint32_t IRQn, uint32_t priority) {
    if(IRQn < 0) {
        SCB->SHPR[(IRQn & 0xF)-4] = ((priority << 4) & 0xFF);
    } else {
        NVIC->IP[IRQn] = ((priority << 4) & 0xFF);
    }
}

#endif /* ARMCM0_H */
