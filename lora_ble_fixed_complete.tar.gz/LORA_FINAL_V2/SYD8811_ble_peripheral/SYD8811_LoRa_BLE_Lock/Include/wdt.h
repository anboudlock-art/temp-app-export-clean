/* wdt.h - Watchdog Timer Driver */
#ifndef WDT_H
#define WDT_H

#include <stdint.h>
#include <stdbool.h>

/* WDT registers */
typedef struct {
    volatile uint32_t LOAD;
    volatile uint32_t VALUE;
    volatile uint32_t CONTROL;
    volatile uint32_t INT_CLR;
    volatile uint32_t RIS;
    volatile uint32_t MIS;
    volatile uint32_t LOCK;
} WDT_Type;

#define WDT_BASE 0x40030000
#define WDT ((WDT_Type *)WDT_BASE)

/* Control register bits */
#define WDT_ENABLE       (1 << 0)
#define WDT_INT_ENABLE   (1 << 1)
#define WDT_RESET_ENABLE (1 << 2)

/* Lock register */
#define WDT_UNLOCK_KEY   0x1ACCE551
#define WDT_LOCK_KEY     0x00000001

/* Functions */
void wdt_init(uint32_t timeout_ms);
void wdt_feed(void);
void wdt_disable(void);
void wdt_enable(void);
bool wdt_interrupt_pending(void);
void wdt_clear_interrupt(void);

#endif /* WDT_H */
