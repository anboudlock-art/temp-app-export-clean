/* spi.h - SPI Driver for SYD8811 */
#ifndef SPI_H
#define SPI_H

#include <stdint.h>
#include <stdbool.h>

/* SPI registers */
typedef struct {
    volatile uint32_t CONTROL;
    volatile uint32_t STATUS;
    volatile uint32_t DATA;
    volatile uint32_t CLOCK;
    volatile uint32_t INT_EN;
    volatile uint32_t INT_STATUS;
} SPI_Type;

/* SPI instances */
#define SPI0_BASE 0x40050000
#define SPI1_BASE 0x40051000
#define SPI0 ((SPI_Type *)SPI0_BASE)
#define SPI1 ((SPI_Type *)SPI1_BASE)

/* Control register bits */
#define SPI_ENABLE        (1 << 0)
#define SPI_MASTER        (1 << 1)
#define SPI_CPOL          (1 << 2)
#define SPI_CPHA          (1 << 3)
#define SPI_LSB_FIRST     (1 << 4)
#define SPI_8BIT         (0 << 5)
#define SPI_16BIT        (1 << 5)
#define SPI_32BIT        (2 << 5)

/* Clock divisors */
#define SPI_CLK_DIV_2    0
#define SPI_CLK_DIV_4    1
#define SPI_CLK_DIV_8    2
#define SPI_CLK_DIV_16   3
#define SPI_CLK_DIV_32   4
#define SPI_CLK_DIV_64   5
#define SPI_CLK_DIV_128  6

/* Functions */
void spi_init(SPI_Type *spi, uint32_t clock_div, bool master, bool cpol, bool cpha);
uint8_t spi_transfer_byte(SPI_Type *spi, uint8_t data);
void spi_transfer_buffer(SPI_Type *spi, const uint8_t *tx_buf, uint8_t *rx_buf, uint32_t len);
bool spi_busy(SPI_Type *spi);

#endif /* SPI_H */
