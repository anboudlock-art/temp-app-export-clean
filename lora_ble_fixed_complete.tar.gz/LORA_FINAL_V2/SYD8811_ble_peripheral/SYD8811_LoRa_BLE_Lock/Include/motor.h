/* motor.h - Motor Driver */
#ifndef MOTOR_H
#define MOTOR_H

#include <stdint.h>
#include <stdbool.h>

/* Motor directions */
typedef enum {
    MOTOR_DIRECTION_FORWARD = 0,
    MOTOR_DIRECTION_REVERSE,
    MOTOR_DIRECTION_STOP
} motor_direction_t;

/* Motor control functions */
void motor_init(void);
void motor_set_direction(motor_direction_t direction);
void motor_set_speed(uint8_t speed);  // 0-100%
void motor_start(void);
void motor_stop(void);
void motor_brake(void);
bool motor_is_running(void);
void motor_update(void);

#endif /* MOTOR_H */
