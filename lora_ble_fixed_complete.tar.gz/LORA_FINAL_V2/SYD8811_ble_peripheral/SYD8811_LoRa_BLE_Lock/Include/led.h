/* led.h - LED Driver */
#ifndef LED_H
#define LED_H

#include <stdint.h>
#include <stdbool.h>

/* LED colors */
typedef enum {
    LED_COLOR_RED = 0,
    LED_COLOR_GREEN,
    LED_COLOR_BLUE,
    LED_COLOR_YELLOW,
    LED_COLOR_CYAN,
    LED_COLOR_MAGENTA,
    LED_COLOR_WHITE
} led_color_t;

/* LED patterns */
typedef enum {
    LED_PATTERN_OFF = 0,
    LED_PATTERN_ON,
    LED_PATTERN_BLINK,
    LED_PATTERN_BREATHE,
    LED_PATTERN_FLASH
} led_pattern_t;

/* LED control functions */
void led_init(void);
void led_set_color(led_color_t color);
void led_set_pattern(led_pattern_t pattern, uint32_t interval_ms);
void led_set_brightness(uint8_t brightness);
void led_update(void);
void led_test_pattern(void);

#endif /* LED_H */
