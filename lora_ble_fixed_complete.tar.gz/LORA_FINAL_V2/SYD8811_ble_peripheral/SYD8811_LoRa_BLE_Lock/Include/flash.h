/* flash.h - Flash Memory Driver */
#ifndef FLASH_H
#define FLASH_H

#include <stdint.h>
#include <stdbool.h>

/* Flash operations */
#define FLASH_OP_READ    0
#define FLASH_OP_WRITE   1
#define FLASH_OP_ERASE   2
#define FLASH_OP_PROGRAM 3

/* Flash status */
#define FLASH_STATUS_IDLE     0
#define FLASH_STATUS_BUSY     1
#define FLASH_STATUS_ERROR    2
#define FLASH_STATUS_PROTECTED 3

/* Flash sizes */
#define FLASH_SIZE_256KB  0x00040000
#define FLASH_SIZE_512KB  0x00080000
#define FLASH_SIZE_1MB    0x00100000

/* Functions */
void flash_init(void);
bool flash_read(uint32_t addr, uint8_t *data, uint32_t len);
bool flash_write(uint32_t addr, const uint8_t *data, uint32_t len);
bool flash_erase_sector(uint32_t addr);
bool flash_erase_chip(void);
uint32_t flash_get_size(void);
uint8_t flash_get_status(void);
void flash_wait_ready(void);

/* Utility functions */
bool flash_write_parameter(uint32_t addr, const void *data, uint32_t size);
bool flash_read_parameter(uint32_t addr, void *data, uint32_t size);

#endif /* FLASH_H */
