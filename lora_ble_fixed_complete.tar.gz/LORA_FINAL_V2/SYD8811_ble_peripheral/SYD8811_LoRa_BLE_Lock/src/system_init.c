/* SystemInit.c - System initialization for SYD8811 */
#include "ARMCM0.h"
#include "config.h"

/* System Clock Frequency (Core Clock) */
uint32_t SystemCoreClock = 16000000;  /* 16 MHz */

/* System initialization */
void SystemInit(void) {
    /* Set vector table offset */
    SCB->VTOR = 0x00000000;  /* FLASH_BASE */
    
    /* Configure system clock */
    /* SYD8811 uses internal 16MHz RC oscillator by default */
    
    /* Enable necessary peripherals */
    /* Clock gating control would go here */
    
    /* Initialize FPU (not present on Cortex-M0) */
    
    /* Configure SysTick */
    SysTick->LOAD = (SystemCoreClock / 1000) - 1;  /* 1ms tick */
    SysTick->VAL  = 0;
    SysTick->CTRL = 0x07;  /* CLKSOURCE + TICKINT + ENABLE */
    
    /* Enable interrupts */
    __enable_irq();
}

/* Get system core clock frequency */
uint32_t SystemCoreClockUpdate(void) {
    /* Update SystemCoreClock variable */
    return SystemCoreClock;
}
