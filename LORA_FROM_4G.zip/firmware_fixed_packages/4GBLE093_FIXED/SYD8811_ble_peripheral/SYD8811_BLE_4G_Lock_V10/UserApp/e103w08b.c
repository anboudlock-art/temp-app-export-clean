#include "uart.h"
#include "gpio.h"
#include "e103w08b.h"
#include "Uart_4G.h"
#include "uart.h"
#include "UART_T.h"
#include "DebugLog.h"
#include "cpwm.h"

static UART_CTRL_TYPE * UART_1_CTRL = ((UART_CTRL_TYPE *) UART_1_CTRL_BASE);

e103w08b_rx_buff_def e103w08_urx_buf;
e103w08b_tx_buff_def e103w08_utx_buf;

void e103w08b_uart_init(void)
{
	// PIN_CONFIG->PIN_5_SEL = PIN_SEL_UART_TXD1;//PIN_SEL_UART_RXD1;
	// PIN_CONFIG->PIN_6_SEL = PIN_SEL_UART_RXD1;//PIN_SEL_UART_TXD1;
   dbg_printf("4G_UART_INI");
	
	PIN_CONFIG->PIN_5_SEL = PIN_SEL_UART_RXD1;
	PIN_CONFIG->PIN_6_SEL = PIN_SEL_UART_TXD1;

	PIN_CONFIG->PAD_5_INPUT_PULL_UP = 0;
	PIN_CONFIG->PAD_6_INPUT_PULL_UP = 0;
	
	UART_1_CTRL->CLK_SEL = 0;		/* 1=32M, 0=16M */
	
	UART_1_CTRL->BAUDSEL = UART_BAUD_115200;
	UART_1_CTRL->FLOW_EN = UART_RTS_CTS_DISABLE;
	
	UART_1_CTRL->RX_INT_MASK = 0;	/* 1=MASK */
	UART_1_CTRL->TX_INT_MASK = 1;	/* 1=MASK */
	
	UART_1_CTRL->PAR_FAIL_INT_MASK = 1; /* 1=MASK */
	UART_1_CTRL->par_rx_even = 0;	/* 1=Even, 0=Odd */
	UART_1_CTRL->par_rx_en = 0;		/* 1=Rx Parity check enable */
	
	UART_1_CTRL->par_tx_even = 0;	/* 1=Even, 0=Odd */
	UART_1_CTRL->par_tx_en = 0;		/* 1=Tx Parity check enable */

	//clr Int Flag
	UART_1_CTRL->RI = 0;
	UART_1_CTRL->TI = 0;
	UART_1_CTRL->PAR_FAIL = 1;

	UART_1_CTRL->RX_FLUSH = 1;		/* clr rx fifo and set RX_FIFO_EMPTY */


	uart.rx.buff =  &net4G.Rxbuf[0];//ָ��buff
	uart.tx.buff =  &net4G.Txbuf[0];
	net4G.BC95_status = 0;//
	uart.rx.cnt = 0;
	uart.tx.state = UART_TX_IDLE;


	NVIC_EnableIRQ(UART1_IRQn);

	UART_1_CTRL->UART_EN = 1;
}

/****************************************************************************
UART1����д����
����: uint8_t data Ҫ���͵�����
ע��: 
	  ʹ�������������ʹ��Tx�ж�
****************************************************************************/
void e103w08b_uart_write(uint8_t data)
{
	UART_1_CTRL->TX_DATA = data;
	while(UART_1_CTRL->TI == 0);
	UART_1_CTRL->TI = 0;
}

/****************************************************************************
UART1����д����
����: uint8_t data Ҫ���͵�����
ע��: 
	  ʹ�������������ʹ��Tx�ж�
****************************************************************************/
void e103w08b_uart_write_buff(uint8_t *pData,uint8_t len)
{
	uint16_t i=0;
	do{
		e103w08b_uart_write(pData[i]);
		i++;
		len--;
	}while(len != 0);
}

/****************************************************************************
UART1���ڶ�Rx FIFO����
����:
	pcnt - ���ض������ֽ���
	pbuf - ָ�����ݴ�ŵ�buf
ע��: FIFO����Ϊ4��Ҫ�����buf��С����Ϊ4�ֽ�
****************************************************************************/
void e103w08b_uart_read(uint8_t *pcnt, uint8_t *pbuf)
{
	uint8_t i = 0;
	volatile uint8_t dly = 0;		//�����64Mʱ�ӣ�����Ҫ��delay��ʱ400ns����
	
	while(!UART_1_CTRL->RX_FIFO_EMPTY)
	{
		*(pbuf+i) = UART_1_CTRL->RX_DATA;
		i++;
		//
		dly++;
		dly++;
		dly++;
	}

	*pcnt = i;
}
void e103w08b_uart_close(void)
{
	UART_1_CTRL->UART_EN = 0;
	NVIC_DisableIRQ(UART1_IRQn);
}

void e103w08b_init(void)
{
	extern u8 timerSendFlag;
	flg_4g_EN = 1;
	flg_needred3 = 1;
	_user.powerondelay1s = 200/2;//��ʱ2�뷢

	//����RST��ENΪgpio���ģʽ
	// PIN_Set_GPIO( U32BIT(E103W08B_EN), PIN_SEL_GPIO);
	// GPIO_Set_Output( U32BIT(E103W08B_EN));	
	// GPIO_Pin_Set( U32BIT(E103W08B_EN));
	// GPIO_Pin_Clear(U32BIT(E103W08B_EN));
	// GPIO_Pin_Set(U32BIT(PWR_4G));		
	e103w08b_uart_init();	//gpio05->TXD gpio06->RXD ���������ж�
	timerSendFlag=0;//YCY:260101
}

void e103w08b_uart_callback(void)
{
	uint8_t i, len, buf[4];
	
	e103w08b_uart_read(&len, buf);
	
	for(i=0;i<len;i++)
	{
		uart.rx.buff[uart.rx.cnt] = buf[i];
		
		if(uart.rx.cnt<100)     uart.rx.cnt++;
		else uart.rx.cnt=0;
	}
	uart.rx.delay = 100/2;////��ʱ100ms
	dbg_printf("%s",buf);
}

/*****************************************************************************
UART1�����жϺ���
ע��:
	  RX_FLUSHֻ����λRX_FIFO_EMPTY,�������RI
*****************************************************************************/
void UART1_IRQHandler(void)
{
	if ((UART_1_CTRL->RI) == 1)
	{
		//�����ݵ�buf[]��
		UART_1_CTRL->RI = 0;		//�����־���ٶ�����		
		e103w08b_uart_callback();
	}

#if 0	
	if ((UART_1_CTRL->TI) == 1)
	{
		UART_1_CTRL->TI = 0;
	}
#endif
	
#if 0
	if((UART_1_CTRL->PAR_FAIL) == 1)
	{
		UART_1_CTRL->PAR_FAIL = 1;
	}
#endif
}

