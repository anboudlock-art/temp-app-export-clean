
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'SYD8811_BLE_4G_Lock_V01' 
 * Target:  'SYD8811' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "ARMCM0.h"



#endif /* RTE_COMPONENTS_H */
