# 固件修改说明

## 修改内容（两套固件相同）
1. 取消注释 SystemParameter 结构体
2. 取消注释 UpdateFlashParameter() 函数
3. 取消注释 ConfigParameterDefault() 函数
4. 取消注释 SetAllParaDefault() 函数（默认密码改为 000000）
5. hardware_init() 中添加 ConfigParameterDefault() 调用
6. 0x21 密码修改处理从 len==5 移到 len==10 分支
7. 0x21 添加完整密码存储逻辑

## 使用方法
1. 用修改后的 user_app.c 替换原项目中的 UserApp/user_app.c
2. 在 Keil 中打开项目
3. 编译（Build）
4. 刷入锁中测试

## 默认密码
修改后默认密码为 000000（6个零）
