;******************************************************************************
;* File: startup_ARMCM0.s
;* Description: CMSIS Cortex-M0 Core Device Startup File for SYD8811
;******************************************************************************

                PRESERVE8
                THUMB

; Vector Table Mapped to Address 0 at Reset

                AREA    RESET, DATA, READONLY
                EXPORT  __Vectors
                EXPORT  __Vectors_End
                EXPORT  __Vectors_Size

__Vectors       DCD     __initial_sp              ; Top of Stack
                DCD     Reset_Handler             ; Reset Handler
                DCD     NMI_Handler               ; NMI Handler
                DCD     HardFault_Handler         ; Hard Fault Handler
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     SVC_Handler               ; SVCall Handler
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     PendSV_Handler            ; PendSV Handler
                DCD     SysTick_Handler           ; SysTick Handler

                ; External Interrupts
                DCD     UART0_IRQHandler          ; 0: UART0
                DCD     UART1_IRQHandler          ; 1: UART1
                DCD     SPI0_IRQHandler           ; 2: SPI0
                DCD     SPI1_IRQHandler           ; 3: SPI1
                DCD     I2C0_IRQHandler           ; 4: I2C0
                DCD     I2C1_IRQHandler           ; 5: I2C1
                DCD     TIMER0_IRQHandler         ; 6: TIMER0
                DCD     TIMER1_IRQHandler         ; 7: TIMER1
                DCD     WDT_IRQHandler            ; 8: WDT
                DCD     GPIO_IRQHandler           ; 9: GPIO
                DCD     ADC_IRQHandler            ; 10: ADC
                DCD     RTC_IRQHandler            ; 11: RTC
                DCD     PWM_IRQHandler            ; 12: PWM
                DCD     BLE_IRQHandler            ; 13: BLE

__Vectors_End
__Vectors_Size  EQU     __Vectors_End - __Vectors

                AREA    |.text|, CODE, READONLY

; Reset Handler
Reset_Handler   PROC
                EXPORT  Reset_Handler             [WEAK]
                IMPORT  SystemInit
                IMPORT  __main
                
                LDR     R0, =SystemInit
                BLX     R0
                LDR     R0, =__main
                BX      R0
                ENDP

; Default exception handlers
NMI_Handler     PROC
                EXPORT  NMI_Handler               [WEAK]
                B       .
                ENDP

HardFault_Handler PROC
                EXPORT  HardFault_Handler         [WEAK]
                B       .
                ENDP

SVC_Handler     PROC
                EXPORT  SVC_Handler               [WEAK]
                B       .
                ENDP

PendSV_Handler  PROC
                EXPORT  PendSV_Handler            [WEAK]
                B       .
                ENDP

SysTick_Handler PROC
                EXPORT  SysTick_Handler           [WEAK]
                B       .
                ENDP

; Default interrupt handlers
UART0_IRQHandler PROC
                EXPORT  UART0_IRQHandler          [WEAK]
                B       .
                ENDP

UART1_IRQHandler PROC
                EXPORT  UART1_IRQHandler          [WEAK]
                B       .
                ENDP

SPI0_IRQHandler PROC
                EXPORT  SPI0_IRQHandler           [WEAK]
                B       .
                ENDP

SPI1_IRQHandler PROC
                EXPORT  SPI1_IRQHandler           [WEAK]
                B       .
                ENDP

I2C0_IRQHandler PROC
                EXPORT  I2C0_IRQHandler           [WEAK]
                B       .
                ENDP

I2C1_IRQHandler PROC
                EXPORT  I2C1_IRQHandler           [WEAK]
                B       .
                ENDP

TIMER0_IRQHandler PROC
                EXPORT  TIMER0_IRQHandler         [WEAK]
                B       .
                ENDP

TIMER1_IRQHandler PROC
                EXPORT  TIMER1_IRQHandler         [WEAK]
                B       .
                ENDP

WDT_IRQHandler  PROC
                EXPORT  WDT_IRQHandler            [WEAK]
                B       .
                ENDP

GPIO_IRQHandler PROC
                EXPORT  GPIO_IRQHandler           [WEAK]
                B       .
                ENDP

ADC_IRQHandler  PROC
                EXPORT  ADC_IRQHandler            [WEAK]
                B       .
                ENDP

RTC_IRQHandler  PROC
                EXPORT  RTC_IRQHandler            [WEAK]
                B       .
                ENDP

PWM_IRQHandler  PROC
                EXPORT  PWM_IRQHandler            [WEAK]
                B       .
                ENDP

BLE_IRQHandler  PROC
                EXPORT  BLE_IRQHandler            [WEAK]
                B       .
                ENDP

                ALIGN

; User Initial Stack & Heap
                IF      :DEF:__MICROLIB
                EXPORT  __initial_sp
                EXPORT  __heap_base
                EXPORT  __heap_limit
                ELSE
                IMPORT  __use_two_region_memory
                EXPORT  __user_initial_stackheap

__user_initial_stackheap
                LDR     R0, =  Heap_Mem
                LDR     R1, =(Stack_Mem + Stack_Size)
                LDR     R2, = (Heap_Mem +  Heap_Size)
                LDR     R3, = Stack_Mem
                BX      LR

                ALIGN
                ENDIF

                END
