/* config.h - Configuration for SYD8811 LoRa-BLE Lock */
#ifndef CONFIG_H
#define CONFIG_H

#include "ARMCM0.h"
#include "lib.h"

/* Bluetooth configuration */
#define MAX_TX_LENGTH     20
#define MAX_ATT_DATA_SZ   20  /* Added missing definition */

/* System parameters */
typedef struct {
    uint8_t password[3];
    uint8_t flags;
    uint8_t lock_state;
    uint8_t battery_level;
    uint32_t serial_number;
    uint8_t ble_address[6];
    uint8_t lora_address[2];
    uint8_t lora_channel;
    uint8_t lora_power;
} SystemParameter_t;

extern SystemParameter_t SystemParameter;

/* Bluetooth service structure */
typedef struct {
    uint8_t  data[MAX_TX_LENGTH][MAX_ATT_DATA_SZ];
    uint8_t  len[MAX_TX_LENGTH];
    uint8_t  tx_index;
    uint8_t  rx_index;
} BleService_t;

extern BleService_t BleService;

/* Function prototypes */
void UpdateFlashParameter(void);
uint8_t computer_sum(uint8_t *data, uint8_t len);

/* LoRa configuration */
#define LORA_UART          UART1
#define LORA_BAUD_RATE     9600
#define LORA_ENABLE_PIN    GPIO_PIN_18
#define LORA_M0_PIN        GPIO_PIN_14
#define LORA_M1_PIN        GPIO_PIN_12
#define LORA_AUX_PIN       GPIO_PIN_13

#endif /* CONFIG_H */
